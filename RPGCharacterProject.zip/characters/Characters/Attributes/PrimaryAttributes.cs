﻿namespace characters
{
    public class PrimaryAttributes
    {
        private double strength;
        private double dexterity;
        private double intelligence;

        public double Strength { get => strength; set => strength = value; }
        public double Dexterity { get => dexterity; set => dexterity = value; }
        public double Intelligence { get => intelligence; set => intelligence = value; }
    }
}
